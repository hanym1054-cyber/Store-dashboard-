
const express = require('express');
const path = require('path');
const bodyParser = require('body-parser');

const app = express();
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, 'public')));

const USER = "BH-MOA";
const PASS = "181297";

app.post('/login', (req,res)=>{
    const {username, password} = req.body;
    if(username === USER && password === PASS){
        return res.redirect('/dashboard.html');
    }
    res.redirect('/?error=1');
});

app.get('/', (req,res)=>{
    res.sendFile(path.join(__dirname,'public','login.html'));
});

app.listen(3000, ()=> console.log("Server running"));
